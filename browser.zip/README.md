    # Bash

This is a browser unblocked for school. If this gets blocked, fork this project to make your own browser.
This is a firefox browser. I have also made a Google Chrome Browser, though I think firefox is faster so I haven't shared it.
